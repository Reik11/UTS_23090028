let menuIcon = document.querySelector('#menu-icon');
let navbar = document.querySelector('.navbar');

console.log(menuIcon); // Cek apakah menuIcon ditemukan
console.log(navbar); // Cek apakah navbar ditemukan

menuIcon.onclick = () => {
    console.log("Menu icon clicked"); // Pastikan fungsi dipanggil saat ikon diklik
    menuIcon.classList.toggle('bx-x');
    navbar.classList.toggle('active');
};
