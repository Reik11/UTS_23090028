let menuIcon = document.querySelector('#menu-icon');
let navbar = document.querySelector('.navbar');

console.log(menuIcon); // Cek apakah menuIcon ditemukan
console.log(navbar); // Cek apakah navbar ditemukan

menuIcon.onclick = () => {
    console.log("Menu icon clicked"); // Pastikan fungsi dipanggil saat ikon diklik
    menuIcon.classList.toggle('bx-x');
    navbar.classList.toggle('active');
};
const slides = document.querySelector('.slides');
const slideImages = document.querySelectorAll('.slides img');
let counter = 0;
const size = slideImages[0].clientWidth;

function moveToNextSlide() {
    if (counter >= slideImages.length - 1) {
        counter = 0;
    } else {
        counter++;
    }
    slides.style.transform = 'translateX(' + (-size * counter) + 'px)';
}

setInterval(moveToNextSlide, 3000); // Ganti gambar setiap 3 detik

